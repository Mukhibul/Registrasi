<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Login Admin - Universitas Ketutrrare</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="login-container">
    <h2>🏠 Universitas MercuBuana</h2>
    <form action="proses_login.php" method="POST">
      <div class="form-group">
        <label for="username">👤 Username:</label>
        <input type="text" id="username" name="username" required>
      </div>

      <div class="form-group">
        <label for="password">⚙️ Password:</label>
        <input type="password" id="password" name="password" required>
      </div>

      <div class="form-group">
        <input type="checkbox" id="remember"> Remember me
      </div>

      <button type="submit" class="btn-login">LOGIN ADMIN</button>
      <a href="form_mahasiswa.html"><button type="button" class="btn-register">Register Mahasiswa Baru</button></a>

      <div class="login-footer">
        👁 <a href="#">Lupa Password?</a>
      </div>
    </form>
  </div>
</body>
</html>
