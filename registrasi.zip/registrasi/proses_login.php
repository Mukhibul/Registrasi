<?php
$adminUsername = "admin123";
$adminPassword = "rahasia123";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if ($username === $adminUsername && $password === $adminPassword) {
        header("Location: form_mahasiswa.html");
        exit;
    } else {
        echo "<h3 style='text-align:center;'>Username atau password salah!</h3>";
        echo "<p style='text-align:center;'><a href='login.php'>Kembali ke Login</a></p>";
    }
}
?>
