<?php
$host = "localhost";
$user = "root";
$password = "";
$dbname = "db_mahasiswa";

$conn = new mysqli($host, $user, $password, $dbname);
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nama = $_POST['nama'];
    $nim = $_POST['nim'];
    $jurusan = $_POST['jurusan'];
    $agama = $_POST['agama'];
    $jenis_kelamin = $_POST['jenis_kelamin'];

    $sql = "INSERT INTO mahasiswa (nama, nim, jurusan, agama, jenis_kelamin)
            VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssss", $nama, $nim, $jurusan, $agama, $jenis_kelamin);

    if ($stmt->execute()) {
        echo "<h3>Registrasi berhasil!</h3><a href='index.html'>Kembali ke Login</a>";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>
