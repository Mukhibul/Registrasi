<?php
$host = "localhost";
$user = "root";
$password = "";
$dbname = "db_mahasiswa";

$conn = new mysqli($host, $user, $password, $dbname);
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

$sql = "SELECT * FROM mahasiswa ORDER BY id DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Data Mahasiswa Terdaftar</title>
  <link rel="stylesheet" href="style.css">
  <style>
  body {
    font-family: 'Segoe UI', sans-serif;
    background-color: #ecf0f1;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
  }

  .login-container {
    background-color: white;
    padding: 30px 40px;
    border-radius: 10px;
    box-shadow: 0px 0px 15px rgba(0,0,0,0.1);
    width: 700px;
    text-align: center;
  }

  h2 {
    margin-bottom: 20px;
    color: #2c3e50;
  }

  table {
    width: 100%;
    border-collapse: collapse;
    font-size: 14px;
  }

  th, td {
    border: 1px solid #ddd;
    padding: 10px;
  }

  th {
    background-color: #2980b9;
    color: white;
  }

  tr:nth-child(even) {
    background-color: #f9f9f9;
  }

  tr:hover {
    background-color: #f1f1f1;
  }

  .back-button {
    margin-top: 20px;
    display: inline-block;
    padding: 10px 20px;
    background-color: #27ae60;
    color: white;
    border-radius: 5px;
    text-decoration: none;
    font-size: 14px;
  }

  .back-button:hover {
    background-color: #1e8449;
  }
  </style>
</head>
<body>
  <div class="login-container">
    <h2>Data Mahasiswa Terdaftar</h2>

    <table>
      <thead>
        <tr>
          <th>No</th>
          <th>Nama</th>
          <th>NIM</th>
          <th>Jurusan</th>
          <th>Agama</th>
          <th>Jenis Kelamin</th>
        </tr>
      </thead>
      <tbody>
        <?php if ($result->num_rows > 0): 
          $no = 1;
          while($row = $result->fetch_assoc()): ?>
            <tr>
              <td><?= $no++ ?></td>
              <td><?= htmlspecialchars($row["nama"]) ?></td>
              <td><?= htmlspecialchars($row["nim"]) ?></td>
              <td><?= htmlspecialchars($row["jurusan"]) ?></td>
              <td><?= htmlspecialchars($row["agama"]) ?></td>
              <td><?= htmlspecialchars($row["jenis_kelamin"]) ?></td>
            </tr>
        <?php endwhile; else: ?>
            <tr><td colspan="6">Belum ada data.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>

    <a href="form_mahasiswa.html" class="back-button">Tambah Data Baru</a>
  </div>
</body>
</html>

<?php $conn->close(); ?>